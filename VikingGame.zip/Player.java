interface Player
{
    public int[] getMove(vikingGame game);
}
